#include <iostream>
using namespace std;

int main() {
    int ammoBox = 30;
    int boxes = 4;
    int totalAmmo = ammoBox * boxes;

    cout << "Each box has " << ammoBox << " rounds." << endl;
    cout << "Total ammo for " << boxes << " boxes: " << totalAmmo << " rounds." << endl;

    return 0;
}