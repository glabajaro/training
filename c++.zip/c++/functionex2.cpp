#include <iostream>
using namespace std;

void issueAmmo(int soldiers, int roundsPerSoldier) {
    int totalRounds = soldiers * roundsPerSoldier;
    cout << "Issuing " << totalRounds << " rounds for " << soldiers << " soldiers." << endl;
}

int main() {
    issueAmmo(10, 30);
    return 0;
}
