#include <iostream>
using namespace std;

int main() {
    bool isPatrolActive;

    cout << "Is patrol active? (1 = Yes, 0 = No): ";
    cin >> isPatrolActive;

    if (isPatrolActive) {
        cout << "Patrol is underway. Monitoring in progress." << endl;
    } else {
        cout << "Standby mode. Awaiting orders." << endl;
    }

    return 0;
}