#include <iostream>
#include <string>
using namespace std;

int main() {
    string username;
    string password;
    string correctPassword = "navy2025";
    int maxAttempts = 3; // Max number of allowed attempts
    int attempts = 0; // Counter for failed attempts

    cout << "Enter username: ";
    cin >> username;

    // Start while loop to allow up to maxAttempts
    while (attempts < maxAttempts) {
        cout << "Enter password to access secure logs: ";
        cin >> password;

        // If the password is correct, break out of the loop
        if (password == correctPassword) {
            cout << R"(
    _                            ____                 _           _ 
   / \   ___ ___ ___  ___ ___   / ___|_ __ __ _ _ __ | |_ ___  __| |
  / _ \ / __/ __/ _ \/ __/ __| | |  _| '__/ _` | '_ \| __/ _ \/ _` |
 / ___ \ (_| (_|  __/\__ \__ \ | |_| | | | (_| | | | | ||  __/ (_| |
/_/   \_\___\___\___||___/___/  \____|_|  \__,_|_| |_|\__\___|\__,_| 
)";
            return 0;  // Exit the program after successful login
        }
        
        // If the password is incorrect, increment the attempts counter
        attempts++;

        cout << R"(
    _                           ____             _          _   
   / \   ___ ___ ___  ___ ___  |  _ \  ___ _ __ (_) ___  __| |  
  / _ \ / __/ __/ _ \/ __/ __| | | | |/ _ \ '_ \| |/ _ \/ _` |  
 / ___ \ (_| (_|  __/\__ \__ \ | |_| |  __/ | | | |  __/ (_| |_ 
/_/___\_\___\___\___||___/___/ |____/_\___|_| |_|_|\___|\__,_(_)
|_   _| __ _   _    __ _  __ _  __ _(_)_ __                     
  | || '__| | | |  / _` |/ _` |/ _` | | '_ \                    
  | || |  | |_| | | (_| | (_| | (_| | | | | |_                  
  |_||_|   \__, |  \__,_|\__, |\__,_|_|_| |_(_)                 
           |___/         |___/     
)";

        // If max attempts are reached, exit the program
        if (attempts >= maxAttempts) {
            cout << R"(
 _____                                            __       _ _          _   
|_   _|__   ___    _ __ ___   __ _ _ __  _   _   / _| __ _(_) | ___  __| |  
  | |/ _ \ / _ \  | '_ ` _ \ / _` | '_ \| | | | | |_ / _` | | |/ _ \/ _` |  
  | | (_) | (_) | | | | | | | (_| | | | | |_| | |  _| (_| | | |  __/ (_| |  
  |_|\___/ \___/  |_| |_| |_|\__,_|_| |_|\__, | |_|  \__,_|_|_|\___|\__,_|  
  __ _| |_| |_ ___ _ __ ___  _ __ | |_ __|___/   / \   ___ ___ ___  ___ ___ 
 / _` | __| __/ _ \ '_ ` _ \| '_ \| __/ __|     / _ \ / __/ __/ _ \/ __/ __|
| (_| | |_| ||  __/ | | | | | |_) | |_\__ \_   / ___ \ (_| (_|  __/\__ \__ \
 \__,_|\__|\__\___|_| |_| |_| .__/ \__|___(_) /_/   \_\___\___\___||___/___/
| | ___   ___| | _____  __| |_|                                             
| |/ _ \ / __| |/ / _ \/ _` |                                               
| | (_) | (__|   <  __/ (_| |_                                              
|_|\___/ \___|_|\_\___|\__,_(_)                                             
)";

            return 0;  // Exit the program after too many failed attempts
        }
    }

    return 0;
}
