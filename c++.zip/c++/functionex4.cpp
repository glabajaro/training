#include <iostream>
using namespace std;

float computeFuelRequirement(float distanceKm, float fuelPerKm) {
    return distanceKm * fuelPerKm;
}

int main() {
    float distance, fuelRate;
    cout << "Enter mission distance (km): ";
    cin >> distance;
    cout << "Enter fuel consumption per km: ";
    cin >> fuelRate;

    float fuelNeeded = computeFuelRequirement(distance, fuelRate);
    cout << "Total fuel required: " << fuelNeeded << " liters." << endl;

    return 0;
}
