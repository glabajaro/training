#include <iostream>
using namespace std;

int main() {
    for (int row = 1; row <= 3; row++) {
        for (int col = 1; col <= 3; col++) {
            cout << "Scanning grid [" << row << "][" << col << "]..." << endl;
        }
    }

    return 0;
}