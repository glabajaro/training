#include <iostream>
using namespace std;

void displayWelcome() {
    cout << "=============================" << endl;
    cout << "  Philippine Navy System" << endl;
    cout << "=============================" << endl;
}

int main() {
    displayWelcome();
    cout << "System initializing..." << endl;
    return 0;
}