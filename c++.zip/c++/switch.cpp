#include <iostream>
using namespace std;

int main() {
    int choice;

    cout << "NAVAL COMMAND MENU" << endl;
    cout << "[1] Activate sonar" << endl;
    cout << "[2] Launch drone" << endl;
    cout << "[3] Shut down system" << endl;
    cout << "Select option: ";
    cin >> choice;

    switch (choice) {
        case 1:
            cout << "Sonar system activated." << endl;
            break;
        case 2:
            cout << "Drone launched successfully." << endl;
            break;
        case 3:
            cout << "System shutting down." << endl;
            break;
        default:
            cout << "Invalid option. Try again." << endl;
    }

    return 0;
}