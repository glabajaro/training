#include <iostream>
using namespace std;

int main() {
    int age = 30;
    float height = 5.9;
    char grade = 'A';
    string name = "Lt. Reyes";
    bool isActive = true;

    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Height: " << height << " ft" << endl;
    cout << "Performance Grade: " << grade << endl;
    cout << "Active Duty: " << isActive << endl;

    return 0;
}