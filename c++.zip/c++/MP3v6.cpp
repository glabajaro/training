#include <iostream>
using namespace std;

int main() {
    int radarRange, objectRange;

    // Get user input for the radar range and object range
    cout << "Enter the radar range (in kilometers): ";
    cin >> radarRange;
    cout << "Enter the object range (in kilometers): ";
    cin >> objectRange;

    for (int y = radarRange; y >= 0; --y)
    {
        for (int x = 0; x <= radarRange; ++x){
            if (x == radarRange && y == radarRange)
            cout << "X";
            else
            cout << "-";
        }

        cout << "\n";
    }
    return 0;
}