#include <iostream>
#include <string>
using namespace std;

int main() {
    string password;
    string username;
    string correctPassword = "navy2025";
    int maxAttempts = 3; // Max number of allowed attempts
    int attempts = 0; // Counter for failed attempts

    cout << "Enter username: ";
    cin >> username;

    do {

        cout << "Enter password to access secure logs: ";
        cin >> password;

        // Check if the entered password is correct
        if (password != correctPassword) {
            attempts++; // Increment failed attempt count
            cout << R"(
    _                           ____             _          _   
   / \   ___ ___ ___  ___ ___  |  _ \  ___ _ __ (_) ___  __| |  
  / _ \ / __/ __/ _ \/ __/ __| | | | |/ _ \ '_ \| |/ _ \/ _` |  
 / ___ \ (_| (_|  __/\__ \__ \ | |_| |  __/ | | | |  __/ (_| |_ 
/_/___\_\___\___\___||___/___/ |____/_\___|_| |_|_|\___|\__,_(_)
|_   _| __ _   _    __ _  __ _  __ _(_)_ __                     
  | || '__| | | |  / _` |/ _` |/ _` | | '_ \                    
  | || |  | |_| | | (_| | (_| | (_| | | | | |_                  
  |_||_|   \__, |  \__,_|\__, |\__,_|_|_| |_(_)                 
           |___/         |___/     
)";

            if (attempts >= maxAttempts) {
                cout << R"(
 _____                                            __       _ _          _   
|_   _|__   ___    _ __ ___   __ _ _ __  _   _   / _| __ _(_) | ___  __| |  
  | |/ _ \ / _ \  | '_ ` _ \ / _` | '_ \| | | | | |_ / _` | | |/ _ \/ _` |  
  | | (_) | (_) | | | | | | | (_| | | | | |_| | |  _| (_| | | |  __/ (_| |  
  |_|\___/ \___/  |_| |_| |_|\__,_|_| |_|\__, | |_|  \__,_|_|_|\___|\__,_|  
  __ _| |_| |_ ___ _ __ ___  _ __ | |_ __|___/   / \   ___ ___ ___  ___ ___ 
 / _` | __| __/ _ \ '_ ` _ \| '_ \| __/ __|     / _ \ / __/ __/ _ \/ __/ __|
| (_| | |_| ||  __/ | | | | | |_) | |_\__ \_   / ___ \ (_| (_|  __/\__ \__ \
 \__,_|\__|\__\___|_| |_| |_| .__/ \__|___(_) /_/   \_\___\___\___||___/___/
| | ___   ___| | _____  __| |_|                                             
| |/ _ \ / __| |/ / _ \/ _` |                                               
| | (_) | (__|   <  __/ (_| |_                                              
|_|\___/ \___|_|\_\___|\__,_(_)                                             
)";
                return 0;  // Exit the program after too many failed attempts
            }
        }

    } while (password != correctPassword);

    // If correct password entered within attempt limit
    cout << R"(
    _                            ____                 _           _ 
   / \   ___ ___ ___  ___ ___   / ___|_ __ __ _ _ __ | |_ ___  __| |
  / _ \ / __/ __/ _ \/ __/ __| | |  _| '__/ _` | '_ \| __/ _ \/ _` |
 / ___ \ (_| (_|  __/\__ \__ \ | |_| | | | (_| | | | | ||  __/ (_| |
/_/   \_\___\___\___||___/___/  \____|_|  \__,_|_| |_|\__\___|\__,_| 
)";

    return 0;
}
