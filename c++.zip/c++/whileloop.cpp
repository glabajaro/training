#include <iostream>
using namespace std;

int main() {
    int countdown = 10;

    cout << "Initiating drone launch countdown..." << endl;

    while (countdown > 0) {
        cout << countdown << "..." << endl;
        countdown--;
    }

    cout << "🚀 Drone launched!" << endl;

    return 0;
}