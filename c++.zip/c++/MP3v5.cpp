#include <iostream> 
using namespace std;

int main() {
    int radarRange, objectRange;

    // Get user input for the radar range and object range
    cout << "Enter the radar range (in kilometers): ";
    cin >> radarRange;
    cout << "Enter the object range (in kilometers): ";
    cin >> objectRange;

    // Input validation
    if (radarRange <= 0 || objectRange < 0) {
        cout << "Please enter valid ranges (positive numbers)." << endl;
        return 1;
    }

    // Simulate the radar tracking up to the specified range
    cout << "\nSimulating Radar Tracking:\n";
    cout << "Radar Range: " << radarRange << " km, Object Range: " << objectRange << " km\n";

    // Create the square radar grid and display the object
    for (int i = 0; i < radarRange; ++i) {
        for (int j = 0; j < radarRange; ++j) {
            // If we're at the object range, mark it with an "X"
            if (i == objectRange - 1 && j == objectRange - 1) {
                cout << "X";  // "X" marks the object position
            } else {
                // Empty space inside the grid
                cout << "-";
            }
        }
        cout << endl;  // Move to the next line after each row
    }

    // Display tracking information
    if (objectRange <= radarRange) {
        cout << "\nObject is within radar range and tracked at " << objectRange << " km!" << endl;
    } else {
        cout << "\nObject is out of radar range!" << endl;
    }

    return 0;
}