#include <iostream>
using namespace std;

int main() {
    float kilometers;
    float nauticalMiles;
    const float KM_TO_NM = 0.539957;

    cout << "Enter distance in kilometers: ";
    cin >> kilometers;

    nauticalMiles = kilometers * KM_TO_NM;

    cout << kilometers << " km is approximately " << nauticalMiles << " nautical miles." << endl;

    return 0;
}