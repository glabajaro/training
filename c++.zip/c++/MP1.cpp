#include <iostream>
#include <string>
using namespace std;

// Function to convert km to nautical miles
void convertFunction() {
    float km;

    // Ask for the distance in km
    cout << "Insert value in km: ";
    cin >> km;

    // Perform the conversion to nautical miles
    float result = km * 0.539957;
    cout << "Equivalent distance: " << result << " nautical miles." << endl;
}

int main() {
    string name, answer;

    // Ask for the user's name only once at the beginning
    cout << "Enter your name: ";
    cin >> name;

    do {
        // Call the convert function to perform the conversion
        convertFunction();

        // Ask the user if they want to continue
        cout << "Do you want to convert another value? (Yes/No): ";
        cin >> answer;

        // If the answer is not Yes or No, prompt again
        while (answer != "Yes" && answer != "No") {
            cout << "Invalid input. Please type 'Yes' or 'No': ";
            cin >> answer;
        }

    } while (answer == "Yes");  // Continue if the user answered "Yes"

    cout << "Goodbye, " << name << "!" << endl;  // Personalized goodbye message
    
    return 0;
}
