#include <iostream>
#include <string>

#ifdef _WIN32
#include <conio.h>  // For _getch() on Windows
#else
#include <termios.h>
#include <unistd.h>
#endif

std::string getPassword(const std::string& prompt = "Enter password: ") {
    std::string password;
    char ch;

    std::cout << prompt;

#ifdef _WIN32
    while (true) {
        ch = _getch();
        if (ch == '\r' || ch == '\n') {
            std::cout << std::endl;
            break;
        } else if (ch == '\b') {
            if (!password.empty()) {
                password.pop_back();
                std::cout << "\b \b";
            }
        } else if (ch == 3) { // Ctrl+C
            exit(1);
        } else {
            password += ch;
            std::cout << '*';
        }
    }
#else
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ECHO | ICANON);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    while (true) {
        ch = getchar();
        if (ch == '\n' || ch == '\r') {
            std::cout << std::endl;
            break;
        } else if (ch == 127 || ch == 8) {
            if (!password.empty()) {
                password.pop_back();
                std::cout << "\b \b";
            }
        } else if (ch == 3) {
            tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
            exit(1);
        } else {
            password += ch;
            std::cout << '*';
        }
    }

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif

    return password;
}

int main() {
    const std::string validUsername = "navy";
    const std::string validPassword = "navy";

    std::string username;
    std::cout << "Enter username: ";
    std::getline(std::cin, username);

    std::string password = getPassword("Enter password: ");

    std::cout << "\nLogin attempt:\n";

    if (username == validUsername && password == validPassword) {
        std::cout << "✅ Access granted. Welcome, " << username << "!\n";
    } else {
        std::cout << "❌ Access denied. Invalid credentials.\n";
    }

    return 0;
}