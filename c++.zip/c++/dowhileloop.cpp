#include <iostream>
#include <string>
using namespace std;

int main() {
    string password;
    string correctPassword = "navy2025";

    do {
        cout << "Enter password to access secure logs: ";
        cin >> password;

        if (password != correctPassword) {
            cout << "❌ Access Denied. Try again.\n";
        }

    } while (password != correctPassword);

    cout << "✅ Access Granted." << endl;

    return 0;
}
