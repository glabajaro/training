#include <iostream>
using namespace std;

float calculateNauticalMiles(float kilometers) {
    return kilometers * 0.539957;
}

int main() {
    float distanceKm;
    cout << "Enter distance in kilometers: ";
    cin >> distanceKm;

    float result = calculateNauticalMiles(distanceKm);
    cout << "Equivalent distance: " << result << " nautical miles." << endl;

    return 0;
}
