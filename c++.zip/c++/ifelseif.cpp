#include <iostream>
using namespace std;

int main() {
    int missionCode;

    cout << "Enter mission code (1-3): ";
    cin >> missionCode;

    if (missionCode == 1) {
        cout << "Mission: Surveillance Operation" << endl;
    } else if (missionCode == 2) {
        cout << "Mission: Rescue and Recovery" << endl;
    } else if (missionCode == 3) {
        cout << "Mission: Maritime Patrol" << endl;
    } else {
        cout << "Invalid mission code!" << endl;
    }

    return 0;
}