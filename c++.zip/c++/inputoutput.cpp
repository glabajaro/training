#include <iostream>
using namespace std;

int main() {
    string name;
    int yearsInService;

    cout << "Enter your name: ";
    getline(cin, name);

    cout << "Enter years in service: ";
    cin >> yearsInService;

    cout << "Officer " << name << " has served for " << yearsInService << " years." << endl;

    return 0;
}