import csv
import getpass
import os

USER_DB = {
    "admin": "navypass123",
    "officer": "securepass",
    "guest": "guestpass"
}

CSV_FILENAME = "navy_equipment.csv"

def load_data(filename):
    data = []
    if not os.path.exists(filename):
        print(f"File '{filename}' not found. Starting with empty inventory.")
        return data

    with open(filename, mode='r', newline='') as file:
        reader = csv.DictReader(file)
        for row in reader:
            try:
                data.append({
                    'equipment': row['Equipment'].strip(),
                    'units': int(row['Units']),
                    'budget': float(row['Budget'])
                })
            except KeyError as e:
                print(f"❌ Missing expected column in CSV: {e}")
            except ValueError as e:
                print(f"❌ Invalid data format: {e}")
    return data

def display_data(data):
    if not data:
        print("\nNo equipment data available.\n")
        return
    print("\nCurrent Navy Equipment Inventory:")
    print(f"{'ID':<4}{'Equipment Name':<25}{'Units':<10}{'Budget':<10}")
    print("-" * 50)
    for idx, item in enumerate(data, start=1):
        print(f"{idx:<4}{item['equipment']:<25}{item['units']:<10}{item['budget']:<10.2f}")
    print()

def confirm_password(username):
    pw = getpass.getpass("Re-enter password to confirm: ")
    return USER_DB.get(username) == pw

def add_entry(data, username):
    if not confirm_password(username):
        print("Password incorrect. Action cancelled.\n")
        return
    name = input("Enter equipment name: ").strip()
    try:
        units = int(input("Enter number of units: "))
        budget = float(input("Enter budget: "))
    except ValueError:
        print("Invalid number format for units or budget. Aborting add.\n")
        return
    data.append({
        "equipment": name,
        "units": units,
        "budget": budget
    })
    print(f"Equipment '{name}' added successfully.\n")

def delete_entry(data, username):
    if not confirm_password(username):
        print("Password incorrect. Action cancelled.\n")
        return
    display_data(data)
    try:
        id_to_delete = int(input("Enter the ID of the equipment to delete: "))
        if 1 <= id_to_delete <= len(data):
            removed = data.pop(id_to_delete - 1)
            print(f"Equipment '{removed['equipment']}' deleted successfully.\n")
        else:
            print("Invalid ID selected.\n")
    except ValueError:
        print("Please enter a valid integer ID.\n")

def modify_entry(data, username):
    if not confirm_password(username):
        print("Password incorrect. Action cancelled.\n")
        return
    display_data(data)
    try:
        id_to_modify = int(input("Enter the ID of the equipment to modify: "))
        if 1 <= id_to_modify <= len(data):
            item = data[id_to_modify - 1]
            print(f"Current Equipment Name: {item['equipment']}")
            new_name = input("Enter new equipment name (leave blank to keep current): ").strip()
            if new_name:
                item['equipment'] = new_name
            print(f"Current Number of Units: {item['units']}")
            new_units = input("Enter new number of units (leave blank to keep current): ").strip()
            if new_units:
                try:
                    item['units'] = int(new_units)
                except ValueError:
                    print("Invalid number format for units. Keeping old value.")
            print(f"Current Budget: {item['budget']}")
            new_budget = input("Enter new budget (leave blank to keep current): ").strip()
            if new_budget:
                try:
                    item['budget'] = float(new_budget)
                except ValueError:
                    print("Invalid number format for budget. Keeping old value.")
            print(f"Equipment ID {id_to_modify} modified successfully.\n")
        else:
            print("Invalid ID selected.\n")
    except ValueError:
        print("Please enter a valid integer ID.\n")

def export_data(data, username):
    export_filename = f"updated_{username}_navy_equipment_tracker.csv"
    try:
        with open(export_filename, mode='w', newline='') as file:
            fieldnames = ['Equipment', 'Units', 'Budget']
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            for item in data:
                writer.writerow({
                    'Equipment': item['equipment'],
                    'Units': item['units'],
                    'Budget': item['budget']
                })
        print(f"✅ Data exported successfully to '{export_filename}'.\n")
    except Exception as e:
        print(f"❌ Export failed: {e}")

def login():
    print("=== Navy Equipment Inventory Management System ===")
    while True:
        username = input("Username: ").strip()
        if username not in USER_DB:
            print("Invalid username. Try again.\n")
            continue
        password = getpass.getpass("Password: ")
        if USER_DB[username] == password:
            print(f"Login successful. Welcome, {username}!\n")
            return username
        else:
            print("Incorrect password. Try again.\n")

def main():
    username = login()
    data = load_data(CSV_FILENAME)

    while True:
        print("=" * 60)
        print(f"| Navy Equipment Inventory Management - User: {username}       |")
        print("=" * 60)
        print("| [1] View Equipment                                      |")
        print("| [2] Add New Equipment                                   |")
        print("| [3] Delete Equipment                                    |")
        print("| [4] Modify Equipment                                    |")
        print("| [5] Export to CSV                                       |")
        print("| [0] Exit                                                |")
        print("=" * 60)

        choice = input("Enter your choice: ").strip()

        if choice == '1':
            display_data(data)
        elif choice == '2':
            add_entry(data, username)
        elif choice == '3':
            delete_entry(data, username)
        elif choice == '4':
            modify_entry(data, username)
        elif choice == '5':
            export_data(data, username)
        elif choice == '0':
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid choice. Please select a valid option.\n")

if __name__ == "__main__":
    main()
