def main():
    print("Hello, Navy!")

if __name__ == "__main__":
    main()