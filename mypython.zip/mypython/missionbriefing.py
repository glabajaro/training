def generate_report(name, rank, mission_code, location):
    report = f"""
    =======================================
              PHILIPPINE NAVY REPORT
    =======================================
    Officer Name   : {name}
    Rank           : {rank}
    Mission Code   : {mission_code}
    Operation Zone : {location}
    =======================================
    Mission briefing completed.
    """
    return report

# Collect input from user
print("📝 Mission Briefing Input")
officer_name = input("Enter officer's name: ")
rank = input("Enter rank: ")
mission_code = input("Enter mission code (e.g., OP123): ")
location = input("Enter area of operation: ")

# Generate mission briefing report
briefing = generate_report(officer_name, rank, mission_code, location)

# Output to terminal
print(briefing)

# Output to file
file_name = "mission_briefing_report.txt"
with open(file_name, "w") as file:
    file.write(briefing)

print(f"✅ Mission report saved to: {file_name}")
