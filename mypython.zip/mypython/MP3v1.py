import csv
import os
from tkinter import Tk
from tkinter.filedialog import askopenfilename

# --- CONFIG ---
AUTHORIZED_HASH = "2c1743a391305fbf367df8e4f069f9f9"

PERSONNEL_CSV = "personnel.csv"
EQUIPMENT_CSV = "equipment.csv"

# --- Access key verification ---
def verify_access_key():
    from tkinter import Tk
    from tkinter.filedialog import askopenfilename
    import sys

    Tk().withdraw()
    print("Please select the access key file...")
    filepath = askopenfilename(title="Select Access Key File")

    if not filepath:
        print("No file selected. Access denied.")
        sys.exit(1)

    try:
        with open(filepath, "r") as f:
            file_content = f.read().strip()
    except Exception as e:
        print(f"Failed to read file: {e}")
        sys.exit(1)

    print(f"Access key in file: {file_content}")
    print(f"Authorized hash is: {AUTHORIZED_HASH}")

    if file_content == AUTHORIZED_HASH:
        print("Access granted.\n")
        return True
    else:
        print("Access denied: Invalid access key.")
        sys.exit(1)

# --- PERSONNEL MANAGEMENT FUNCTIONS ---

def load_personnel(filename):
    data = []
    if not os.path.exists(filename):
        print(f"File '{filename}' not found. Starting empty personnel directory.")
        return data
    try:
        with open(filename, mode='r', newline='') as f:
            reader = csv.reader(f)
            next(reader, None)  # skip header
            for row in reader:
                if len(row) >= 2:
                    data.append(row[:2])
    except Exception as e:
        print(f"Error loading personnel data: {e}")
    return data

def display_personnel(data):
    if not data:
        print("No personnel data available.")
        return
    print("\nPersonnel Directory:")
    print("ID\tName\t\t\tRank")
    print("-" * 40)
    for i, (name, rank) in enumerate(data, 1):
        print(f"{i}\t{name:<20}\t{rank}")
    print()

def add_personnel(data):
    name = input("Enter name: ").strip()
    rank = input("Enter rank: ").strip()
    if name and rank:
        data.append([name, rank])
        print(f"Added personnel: {name} ({rank})")
    else:
        print("Name and rank cannot be empty.")

def delete_personnel(data):
    display_personnel(data)
    try:
        idx = int(input("Enter ID to delete: ")) - 1
        if 0 <= idx < len(data):
            removed = data.pop(idx)
            print(f"Deleted personnel: {removed[0]}")
        else:
            print("Invalid ID.")
    except ValueError:
        print("Please enter a valid number.")

def modify_personnel(data):
    display_personnel(data)
    try:
        idx = int(input("Enter ID to modify: ")) - 1
        if 0 <= idx < len(data):
            current_name, current_rank = data[idx]
            new_name = input(f"New name (blank to keep '{current_name}'): ").strip()
            new_rank = input(f"New rank (blank to keep '{current_rank}'): ").strip()
            if new_name:
                data[idx][0] = new_name
            if new_rank:
                data[idx][1] = new_rank
            print("Personnel entry updated.")
        else:
            print("Invalid ID.")
    except ValueError:
        print("Please enter a valid number.")

def export_personnel(data):
    filename = "updated_personnel_directory.csv"
    try:
        with open(filename, mode='w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Name", "Rank"])
            writer.writerows(data)
        print(f"Personnel directory exported to '{filename}'.")
    except Exception as e:
        print(f"Failed to export personnel directory: {e}")

# --- EQUIPMENT MANAGEMENT FUNCTIONS ---

def load_equipment(filename):
    data = []
    if not os.path.exists(filename):
        print(f"File '{filename}' not found. Starting empty equipment inventory.")
        return data
    try:
        with open(filename, mode='r', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    data.append({
                        'equipment': row['Equipment'].strip(),
                        'units': int(row['Units']),
                        'budget': float(row['Budget'])
                    })
                except (KeyError, ValueError) as e:
                    print(f"Skipping invalid row: {e}")
    except Exception as e:
        print(f"Error loading equipment data: {e}")
    return data

def display_equipment(data):
    if not data:
        print("No equipment data available.")
        return
    print("\nEquipment Inventory:")
    print(f"{'ID':<4} {'Equipment':<25} {'Units':<10} {'Budget':<10}")
    print("-" * 50)
    for i, item in enumerate(data, 1):
        print(f"{i:<4} {item['equipment']:<25} {item['units']:<10} {item['budget']:<10.2f}")
    print()

def add_equipment(data):
    name = input("Enter equipment name: ").strip()
    try:
        units = int(input("Enter number of units: "))
        budget = float(input("Enter budget: "))
        data.append({"equipment": name, "units": units, "budget": budget})
        print(f"Equipment '{name}' added.")
    except ValueError:
        print("Invalid number format.")

def delete_equipment(data):
    display_equipment(data)
    try:
        idx = int(input("Enter equipment ID to delete: ")) - 1
        if 0 <= idx < len(data):
            removed = data.pop(idx)
            print(f"Deleted equipment: {removed['equipment']}")
        else:
            print("Invalid ID.")
    except ValueError:
        print("Please enter a valid number.")

def modify_equipment(data):
    display_equipment(data)
    try:
        idx = int(input("Enter equipment ID to modify: ")) - 1
        if 0 <= idx < len(data):
            item = data[idx]
            new_name = input(f"New name (blank to keep '{item['equipment']}'): ").strip()
            new_units = input(f"New units (blank to keep '{item['units']}'): ").strip()
            new_budget = input(f"New budget (blank to keep '{item['budget']}'): ").strip()
            if new_name:
                item['equipment'] = new_name
            if new_units:
                try:
                    item['units'] = int(new_units)
                except ValueError:
                    print("Invalid units input; keeping old value.")
            if new_budget:
                try:
                    item['budget'] = float(new_budget)
                except ValueError:
                    print("Invalid budget input; keeping old value.")
            print("Equipment entry updated.")
        else:
            print("Invalid ID.")
    except ValueError:
        print("Please enter a valid number.")

def export_equipment(data):
    filename = f"updated_equipment_inventory.csv"
    try:
        with open(filename, mode='w', newline='') as f:
            fieldnames = ['Equipment', 'Units', 'Budget']
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for item in data:
                writer.writerow({
                    'Equipment': item['equipment'],
                    'Units': item['units'],
                    'Budget': item['budget']
                })
        print(f"Equipment inventory exported to '{filename}'.")
    except Exception as e:
        print(f"Failed to export equipment data: {e}")

# --- MAIN MENU ---

def main_menu():
    # Load initial data once
    personnel_data = load_personnel(PERSONNEL_CSV)
    equipment_data = load_equipment(EQUIPMENT_CSV)
    equipment_user = None

    while True:
        print("=" * 70)
        print("Navy Integrated Management System")
        print("1) Manage Personnel Directory")
        print("2) Manage Equipment Tracker")
        print("3) Export All Updated Files")
        print("0) Exit")
        print("=" * 70)
        choice = input("Choose an option: ").strip()

        if choice == '1':
            while True:
                print("\nPersonnel Directory Management")
                print("1) View All Personnel")
                print("2) Add New Entry")
                print("3) Delete an Entry")
                print("4) Modify an Entry")
                print("5) Export Personnel Directory")
                print("0) Back to Main Menu")
                sub_choice = input("Choose an option: ").strip()
                if sub_choice == '1':
                    display_personnel(personnel_data)
                elif sub_choice == '2':
                    add_personnel(personnel_data)
                elif sub_choice == '3':
                    delete_personnel(personnel_data)
                elif sub_choice == '4':
                    modify_personnel(personnel_data)
                elif sub_choice == '5':
                    export_personnel(personnel_data)
                elif sub_choice == '0':
                    break
                else:
                    print("Invalid option.")
        elif choice == '2':
            while True:
                print(f"\nEquipment Tracker Management")
                print("1) View Equipment")
                print("2) Add Equipment")
                print("3) Delete Equipment")
                print("4) Modify Equipment")
                print("5) Export Equipment Directory")
                print("0) Back to Main Menu")
                sub_choice = input("Choose an option: ").strip()
                if sub_choice == '1':
                    display_equipment(equipment_data)
                elif sub_choice == '2':
                    add_equipment(equipment_data)
                elif sub_choice == '3':
                    delete_equipment(equipment_data)
                elif sub_choice == '4':
                    modify_equipment(equipment_data)
                elif sub_choice == '5':
                    export_equipment(equipment_data)
                elif sub_choice == '0':
                    break
                else:
                    print("Invalid option.")
        elif choice == '3':
            print("\nExporting all updated files...")

            export_personnel(personnel_data)

            export_equipment(equipment_data)

            print("All updated files have been exported.\n")

        elif choice == '0':
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid choice. Please select a valid option.")

# --- MAIN ENTRY POINT ---
if __name__ == "__main__":
    if verify_access_key():
        main_menu()
    else:
        print("Exiting due to failed access key verification.")
