import csv

# Function to load the data from the csv file
def load_data(filename):
    data = []
    try:
        with open(filename, mode='r') as file:
            reader = csv.reader(file)
            for row in reader:
                data.append(row)
    except FileNotFoundError:
        print(f"File {filename} not found, starting with an empty directory.")
    return data

# Function to display the current directory
def display_data(data):
    if not data:
        print("No personnel data available.")
    else:
        print("\nCurrent Personnel Directory:")
        print("Name\t\tRank")
        print("-------------------------")
        for row in data:
            print(f"{row[0]}\t\t{row[1]}")
        print("\n")

# Function to add a new entry to the directory
def add_entry(data):
    name = input("Enter the name: ")
    rank = input("Enter the rank: ")
    data.append([name, rank])
    print(f"Entry for {name} added successfully.")

# Function to delete an existing entry
def delete_entry(data):
    name_to_delete = input("Enter the name of the person to delete: ")
    found = False
    for row in data:
        if row[0].lower() == name_to_delete.lower():
            data.remove(row)
            found = True
            print(f"Entry for {name_to_delete} deleted successfully.")
            break
    if not found:
        print(f"No entry found for {name_to_delete}.")

# Function to modify an existing entry
def modify_entry(data):
    name_to_modify = input("Enter the name of the person to modify: ")
    found = False
    for row in data:
        if row[0].lower() == name_to_modify.lower():
            new_name = input(f"Enter new name (current: {row[0]}): ")
            new_rank = input(f"Enter new rank (current: {row[1]}): ")
            row[0] = new_name if new_name else row[0]
            row[1] = new_rank if new_rank else row[1]
            found = True
            print(f"Entry for {name_to_modify} modified successfully.")
            break
    if not found:
        print(f"No entry found for {name_to_modify}.")

# Function to export the updated data to a new CSV file
def export_data(data):
    filename = "updated_navy_directory.csv"
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(data)
    print(f"Updated directory saved to {filename}.")

# Main function to display menu and handle user input
def main():
    filename = "navy_directory.csv"
    data = load_data(filename)

    while True:
        print("=" * 50)
        print("| Philippine Navy Personnel Directory Management  |")
        print("| [1] View All Personnel                          |")
        print("| [2] Add New Entry                               |")
        print("| [3] Delete an Entry                             |")
        print("| [4] Modify an Entry                             |")
        print("| [5] Export to updated_navy_directory.csv        |")
        print("| [0] Exit Program                                |")
        print("=" * 50)
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            display_data(data)
        elif choice == '2':
            add_entry(data)
        elif choice == '3':
            delete_entry(data)
        elif choice == '4':
            modify_entry(data)
        elif choice == '5':
            export_data(data)
        elif choice == '0':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
