import csv

# Function to load the data from the csv file
def load_data(filename):
    data = []
    try:
        with open(filename, mode='r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip the header row
            for row in reader:
                data.append(row)
    except FileNotFoundError:
        print(f"File {filename} not found, starting with an empty directory.")
    return data

# Function to display the current directory with an ID number
def display_data(data):
    if not data:
        print("No personnel data available.")
    else:
        print("\nCurrent Personnel Directory:")
        print("ID\tName\t\t\tRank")
        print("-------------------------------")
        for idx, row in enumerate(data, start=1):  # Start index at 1
            print(f"{idx}\t{row[0]:<20}\t{row[1]}")  # Adjust spacing for alignment
        print("\n")

# Function to add a new entry to the directory
def add_entry(data):
    name = input("Enter the name: ")
    rank = input("Enter the rank: ")
    data.append([name, rank])
    print(f"Entry for {name} added successfully.")

# Function to delete an existing entry using ID
def delete_entry(data):
    try:
        display_data(data)  # Show all entries before asking for deletion
        id_to_delete = int(input("Enter the ID of the person to delete: ")) - 1  # Subtract 1 to match list index
        if 0 <= id_to_delete < len(data):  # Check if ID is valid
            deleted_person = data.pop(id_to_delete)  # Remove the selected person
            print(f"Entry for {deleted_person[0]} deleted successfully.")
        else:
            print("Invalid ID selected.")
    except ValueError:
        print("Please enter a valid ID.")

# Function to modify an existing entry using ID
def modify_entry(data):
    try:
        display_data(data)  # Show all entries before modification
        id_to_modify = int(input("Enter the ID of the person to modify: ")) - 1  # Subtract 1 to match list index
        if 0 <= id_to_modify < len(data):  # Check if ID is valid
            current_name, current_rank = data[id_to_modify]  # Get the current name and rank
            new_name = input(f"Enter new name (current: {current_name}): ")
            new_rank = input(f"Enter new rank (current: {current_rank}): ")
            if new_name:  # Update name if new one is provided
                data[id_to_modify][0] = new_name
            if new_rank:  # Update rank if new one is provided
                data[id_to_modify][1] = new_rank
            print(f"Entry for {current_name} modified successfully.")
        else:
            print("Invalid ID selected.")
    except ValueError:
        print("Please enter a valid ID.")

# Function to export the updated data to a new CSV file
def export_data(data):
    filename = "updated_navy_directory.csv"
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        # Add header row back while exporting
        writer.writerow(["Name", "Rank"])  # Add the header row to the new file
        writer.writerows(data)  # Write updated directory to CSV
    print(f"Updated directory saved to {filename}.")

# Main function to display menu and handle user input
def main():
    filename = "navy_directory.csv"
    data = load_data(filename)

    while True:
        print("=" * 50)
        print("| Philippine Navy Personnel Directory Management  |")
        print("| [1] View All Personnel                          |")
        print("| [2] Add New Entry                               |")
        print("| [3] Delete an Entry                             |")
        print("| [4] Modify an Entry                             |")
        print("| [5] Export to updated_navy_directory.csv        |")
        print("| [0] Exit Program                                |")
        print("=" * 50)
        
        choice = input("Enter your choice: ").strip()

        if choice == '1':
            display_data(data)
        elif choice == '2':
            add_entry(data)
        elif choice == '3':
            delete_entry(data)
        elif choice == '4':
            modify_entry(data)
        elif choice == '5':
            export_data(data)
        elif choice == '0':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
