import csv
import getpass

# --- Hardcoded User Database ---
USER_DB = {
    "admin":   {"password": "navypass123", "role": "Admin", "assignment": "all"},
    "officer": {"password": "securepass",  "role": "Supervisor", "assignment": "all"},
    "guest":   {"password": "guestpass",   "role": "Standard", "assignment": "operations"}
}

# --- Database Configuration ---
DATABASES = {
    "armament": {
        "filename": "armament.csv",
        "fields": ["Weapon Name", "Type", "Inventory Count"]
    },
    "personnel": {
        "filename": "personnel.csv",
        "fields": ["Full Name", "Rank", "Assignment"]
    },
    "operations": {
        "filename": "operations.csv",
        "fields": ["Mission Code", "Objective", "Status"]
    }
}

# --- Authentication ---
def authenticate():
    print("=== Navy Database Login ===")
    username = input("Username: ").strip()
    password = getpass.getpass("Password: ").strip()

    user = USER_DB.get(username)
    if user and user["password"] == password:
        print(f"\nLogin successful. Welcome, {username}!")
        return username, user["role"], user["assignment"]
    else:
        print("Invalid credentials.\n")
        return None, None, None

# --- File I/O ---
def load_data(db_key):
    filename = DATABASES[db_key]["filename"]
    data = []
    try:
        with open(filename, newline='') as file:
            reader = csv.DictReader(file)
            data = list(reader)
    except FileNotFoundError:
        print(f"{filename} not found. Starting with an empty file.")
    return data

def save_data(db_key, data):
    info = DATABASES[db_key]
    with open(f"updated_{info['filename']}", 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=info["fields"])
        writer.writeheader()
        writer.writerows(data)

def export_all_databases():
    print("\nExporting all updated databases...")
    for db_key in DATABASES:
        data = load_data(db_key)
        save_data(db_key, data)
    print("✅ All databases exported as updated_*.csv files.\n")

# --- CRUD Operations ---
def view_data(db_key):
    data = load_data(db_key)
    print(f"\n--- {db_key.upper()} DATABASE ---")
    if not data:
        print("No records available.")
    else:
        for i, row in enumerate(data, 1):
            print(f"{i}) " + " | ".join(f"{k}: {v}" for k, v in row.items()))

def add_data(db_key):
    entry = {}
    for field in DATABASES[db_key]["fields"]:
        entry[field] = input(f"{field}: ").strip()
    data = load_data(db_key)
    data.append(entry)
    save_data(db_key, data)
    print("✅ Record added.\n")

def modify_data(db_key):
    data = load_data(db_key)
    view_data(db_key)
    try:
        idx = int(input("Enter record number to modify: ")) - 1
        if 0 <= idx < len(data):
            for field in DATABASES[db_key]["fields"]:
                new_value = input(f"{field} (current: {data[idx][field]}): ").strip()
                if new_value:
                    data[idx][field] = new_value
            save_data(db_key, data)
            print("✅ Record updated.\n")
        else:
            print("Invalid record number.")
    except ValueError:
        print("Invalid input.")

def delete_data(db_key):
    data = load_data(db_key)
    view_data(db_key)
    try:
        idx = int(input("Enter record number to delete: ")) - 1
        if 0 <= idx < len(data):
            deleted = data.pop(idx)
            save_data(db_key, data)
            print(f"✅ Deleted record: {deleted}")
        else:
            print("Invalid record number.")
    except ValueError:
        print("Invalid input.")

# --- Main Application Logic ---
def user_session():
    username, role, assignment = authenticate()
    if not username:
        return

    accessible_dbs = list(DATABASES.keys()) if assignment == "all" else [assignment]

    while True:
        print("\n--- MAIN MENU ---")
        for i, db in enumerate(accessible_dbs, 1):
            print(f"{i}) {db.capitalize()} Database")
        if role == "Admin":
            print("4) Export All Updated Files")
        print("0) Logout")

        choice = input("Select an option: ").strip()

        if choice == "0":
            print("Logging out...\n")
            break
        elif role == "Admin" and choice == "4":
            export_all_databases()
            continue

        try:
            db_key = accessible_dbs[int(choice) - 1]
        except (ValueError, IndexError):
            print("Invalid selection.")
            continue

        while True:
            print(f"\n--- {db_key.upper()} MENU ({role}) ---")
            print("1) View Records")
            if role == "Admin":
                print("2) Add Record")
                print("3) Modify Record")
                print("4) Delete Record")
            print("0) Back to Main Menu")

            action = input("Choose an action: ").strip()

            if action == "1":
                view_data(db_key)
            elif action == "2" and role == "Admin":
                add_data(db_key)
            elif action == "3" and role == "Admin":
                modify_data(db_key)
            elif action == "4" and role == "Admin":
                delete_data(db_key)
            elif action == "0":
                break
            else:
                print("Invalid or unauthorized action.")

# --- Continuous Login Loop ---
def main():
    while True:
        user_session()

# --- Start Program ---
if __name__ == "__main__":
    main()